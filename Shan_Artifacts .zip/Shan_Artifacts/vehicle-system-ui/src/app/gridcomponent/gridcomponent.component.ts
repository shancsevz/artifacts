import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gridcomponent',
  templateUrl: './gridcomponent.component.html',
  styleUrls: ['./gridcomponent.component.scss']
})
export class GridcomponentComponent implements OnInit {

  columnDefs = [
    {headerName: 'Id', field: 'id'},
    {headerName: 'Name', field: 'name'},
    {headerName: 'CountryCode', field: 'countryCode'},
    {headerName: 'District', field: 'district'},
    {headerName: 'Population', field: 'population'}
];

//rowData = [];

rowData =[{"id":1,"name":"Kabul","countryCode":"PT","district":"Kabol","population":1780000},{"id":2,"name":"Qandahar","countryCode":"AFG","district":"Qandahar","population":237500},{"id":3,"name":"Herat","countryCode":null,"district":"Herat","population":186800},{"id":4,"name":"Mazar-e-Sharif","countryCode":null,"district":"Balkh","population":127800},{"id":5,"name":"Amsterdam","countryCode":null,"district":"Noord-Holland","population":731200},{"id":6,"name":"Rotterdam","countryCode":null,"district":"Zuid-Holland","population":593321},{"id":7,"name":"Haag","countryCode":null,"district":"Zuid-Holland","population":440900},{"id":8,"name":"Utrecht","countryCode":null,"district":"Utrecht","population":234323},{"id":9,"name":"Eindhoven","countryCode":null,"district":"Noord-Brabant","population":201843},{"id":10,"name":"Tilburg","countryCode":null,"district":"Noord-Brabant","population":193238}];

  constructor() { }

  ngOnInit(): void {
      fetch(
        'http://localhost:8080/rest/cities/all', 
        {
          headers: {
            'Content-Type': 'application/json',
          },
          method: 'GET',
          mode: 'no-cors'
        }
      ).then(result => result.json())
      .then(rowData => this.rowData = rowData);
      
      console.log('After::' + this.rowData);
  }

}
