package com.shans.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.shans.demo.model.City;
import com.shans.demo.repository.cityRepository;
import com.shans.demo.resource.CityResources;

@RunWith(SpringRunner.class)
@WebMvcTest(value = CityResources.class)
@WithMockUser
public class CityResourcesTest {

	
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private CityResources cityRes;
	
	List<City> mockCity =  new ArrayList<>(); 
	
	String exampleCourseJson = "{\"id\":1,\"name\":\"Kabul\",\"countryCode\":\"PT\",\"district\":\"Kabol\",\"population\":1780000}";

	
	@Test
	public void retrieveDetailsForCourse() throws Exception {

		Mockito.when(
				cityRes.getAll()).thenReturn(mockCity);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/rest/cities/all").accept(
				MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		System.out.println(result.getResponse());
		String expected = "{id:Course1,name:Spring,description:10Steps}";


		JSONAssert.assertEquals(expected, result.getResponse()
				.getContentAsString(), false);
	}
	
}
