package com.shans.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shans.demo.model.City;

public interface cityRepository extends JpaRepository<City, Integer> {

}
