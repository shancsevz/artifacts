package com.shans.demo.repository;

import java.util.List;

import com.shans.demo.model.City;

public interface FileExporter {
	public List<City> getFileData(String fileLoc);
}