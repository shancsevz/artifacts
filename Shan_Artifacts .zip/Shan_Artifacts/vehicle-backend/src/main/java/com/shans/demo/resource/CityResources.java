package com.shans.demo.resource;

import org.springframework.web.bind.annotation.RestController;

import com.shans.demo.model.City;
import com.shans.demo.repository.cityRepository;
import com.shans.demo.repository.FileExporter;
import com.shans.demo.service.*;

import java.io.FileReader;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping(value="/rest/cities")
public class CityResources {

	@Autowired
	cityRepository cityRepo;
	
	FileExporter fileExporter;
	
	@GetMapping(value = "/all")
	public List<City> getAll(){
		List<Integer> ids = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		return cityRepo.findAllById(ids);
	}
	
	@PostMapping(value ="/load")
	public List<City> persist(@RequestBody final City city){
		cityRepo.save(city);
		return cityRepo.findAll();
	}
	
	public List<City> getData(FileExporter fileExporter, String file) {
		 List<City> lstCity = null;
		 lstCity = fileExporter.getFileData(file);
		 return lstCity;
   }
	
	@PostMapping(value ="/savefile")
	public String file(String fileName){
		String result = "SUCESS";
try {

	   String[] data = fileName.split("[.]");
	   String type = data[1];
	   List<City> lstCity = null;
	   
	   if(type.equals("csv")) {
		   lstCity = getData(new CSVReader(), fileName);
	   }else if(type.equals("xml")) {
		   lstCity = getData(new XMLReader(), fileName);
	   }else if(type.equals("txt")) {
		   lstCity = getData(new TXTReader(), fileName);
	   }else {
		   lstCity = getData(new OtherFileReader(), fileName);
	   }
	   cityRepo.saveAll(lstCity);
		}
		catch(Exception ex) {
			result = "FAILED";
		}
		
		return result;
	}
}
