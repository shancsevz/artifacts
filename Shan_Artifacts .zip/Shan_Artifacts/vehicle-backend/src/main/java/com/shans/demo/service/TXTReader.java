package com.shans.demo.service;

import java.util.ArrayList;
import java.util.List;

import com.shans.demo.model.City;
import com.shans.demo.repository.FileExporter;

public class TXTReader implements FileExporter {
	@Override
    public List<City> getFileData(String fileLoc) {
        
    	List<City> lstcity = new ArrayList<>(); 
        City city = new City();
        city.setId(4000);
        city.setCountryCode("TXT");
        city.setName("SHAN");
        city.setDistrict("TEST");
        city.setPopulation(999);
        
        lstcity.add(city);
        return lstcity;
    }
}
