package com.shans.demo.service;

import java.util.ArrayList;
import java.util.List;

import com.shans.demo.model.City;
import com.shans.demo.repository.FileExporter;

public class CSVReader implements FileExporter  {

    @Override
    public List<City> getFileData(String fileLoc) {
        
        List<City> lstcity = new ArrayList<>(); 
        City city = new City();
        city.setId(2000);
        city.setCountryCode("EXL");
        city.setName("SHAN");
        city.setDistrict("TEST");
        city.setPopulation(999);
        
        lstcity.add(city);
        return lstcity;
    }

}
